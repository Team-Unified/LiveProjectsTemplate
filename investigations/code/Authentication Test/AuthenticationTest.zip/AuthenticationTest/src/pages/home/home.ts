import { Component } from '@angular/core';
import { NavController, Platform } from 'ionic-angular';
import { Facebook, Google, OauthCordova, Instagram } from 'ionic-cordova-oauth';


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {  

  private oauth: OauthCordova = new OauthCordova();
    private instagramProvider: Instagram = new Instagram ({
      clientId: " *povide client id* ",
      //redirects to http://localhost/callback
      redirectUri: 'https://tinyurl.com/krmpchb',
     // appScope: ["email"]
    })
 
    constructor(private navCtrl: NavController, private platform: Platform) { }
    
    status: string = "";

    insta() {
        this.platform.ready().then(() => {
            this.oauth.logInVia(this.instagramProvider).then(success => {  

              this.status = "Success, you're now connected!";

                console.log("SUCCESS: ", success);
            }, error => {
                console.log("ERROR: ", error);
            });
        });
    }

  
}
